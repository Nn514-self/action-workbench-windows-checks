# Action Workbench · Node.js 业务后端 + 可选 AI

开发者定义一次业务，普通客户端用 HTTP，助手则依权限介绍或代办。运行时生成 OpenAPI 3.1.1 文档；不开模型也能办理全部普通业务。不包含页面、表单或聊天 UI。

## 用框架创建自己的后端

Node.js **22.18+**、npm。在框架根目录：

```sh
npm ci && npm run build                     # 源码目录中编译一次；安装包内已有 JS 和类型声明
node bin/create-action-backend.mjs ../my-product
cd ../my-product
npm install
export WORKBENCH_TOKEN="$(node -p 'crypto.randomUUID()+crypto.randomUUID()')"
npm start                                   # 或 npm run start:ai
```

目标必须是新目录或空目录。生成的项目自带**当前框架的 npm 安装包**，不依赖全局安装、源码软链或尚未发布的 npm 版本。产品里的 `server.ts` 组装模块；`orders.ts`、`expenses.ts` 是可替换的业务，不在框架内核里。也可以直接在框架根目录设置同一环境变量并 `npm start` 体验。服务默认仅监听 `127.0.0.1:4881`，根路径不是网页。

## 开发一个动作

```ts
import { z } from 'zod';
import { defineModule, query } from 'action-workbench';

export const shipping = defineModule('shipping', {
  quote: query({
    description: '按整公斤查询普通快递运费，结果单位为分。',
    http: { method: 'GET', path: '/shipping/quote' },
    permission: 'shipping:read', ai: true,
    input: z.strictObject({ kg: z.coerce.number().int().min(1).max(20) }),
    output: z.strictObject({ cents: z.int() }),
    run: (_ctx, { kg }) => ({ cents: 800 + (kg - 1) * 200 }),
  }),
});
```

把 `shipping` 放入 `createBackend({ database, modules: [...] })`，给相应身份授予 `shipping:read`。此时 `GET /shipping/quote?kg=3` 和助手的 `shipping.quote` 共用业务函数。不改路由总表、模型代码或提示词。输入必须是严格对象；路径、查询串和 JSON 对象按字段合并，重复字段报 `400`，不会互相覆盖。路由中的 `:id` 必须在输入 schema 中声明。命令不能使用 GET；重复模块、冲突路由和 `/_aw` 保留路径启动时拒绝。

写操作有两种：只修改框架所在 SQLite 数据库，用 `sqliteCommand(db, {...})`；调用外部服务、其他数据库或异步任务，用 `command({...})`。两者的权限、HTTP、AI、确认参数相同。`run({ actor, invocationId }, input)` 的身份来自认证回调，不来自业务输入。动作权限不代替数据归属检查：订单更新 SQL 同时限定租户、用户、订单编号与当前状态。业务拒绝可以抛 `new ActionError(409, 'ORDER_ALREADY_SHIPPED', '订单已经发货，不能取消。')`。只返回允许该用户及模型读取的字段。

**助手能介绍什么，不等于它能做什么。** 每个动作的 `ai` 只有一处配置。省略或 `false`：对模型完全隐藏；`'describe'`：只给有权限的用户介绍，不能调用；`true`：可介绍、可发起。仓库员工能从助手了解 `orders.ship`，但发货只能走普通接口；没有 `orders:ship` 的员工在介绍目录和接口文档里都看不到它。模型不会收到仅介绍动作的路由或参数。`description` 应当写给获准知情的用户，不要写内部运维细节。

## 两个入口怎样接手同一笔业务

所有端点都需要 `Authorization: Bearer $WORKBENCH_TOKEN`。在同一环境中发请求，例如：

```sh
curl -sS -H "Authorization: Bearer $WORKBENCH_TOKEN" http://127.0.0.1:4881/_aw/actions
curl -sS -H "Authorization: Bearer $WORKBENCH_TOKEN" -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: first-expense' -d '{"title":"差旅","amount":"46.50"}' \
  http://127.0.0.1:4881/expenses
```

业务路由返回 `{id,action,status,result?}`；`id` 是**调用编号**，不是 `result.id` 里的单据编号。费用模块提供创建、查询、提交、撤回；订单模块提供下单、查询、取消和 HTTP 专用的标记发货。示例不收费、不发出外部审批或物流通知。

| 接口 | 行为 |
| --- | --- |
| `GET /_aw/actions` | 发现当前身份可用的业务动作。模型另取 `ai: true` 且有权限的子集。 |
| `GET /_aw/capabilities` | 当前身份可由助手介绍的功能；`mode: manual` 需手动办理，`assistant` 可代办。 |
| `GET /_aw/openapi.json` | 此身份实际有权调用的 HTTP 路径、参数、输入、结果与确认回执。GET 非路径字段放查询串，其他方法的非路径字段按 JSON 对象发送。不要公开缓存这份文档。 |
| `POST /_aw/assistant/messages` | JSON `{message,conversationId?}`；返回聊天回复或 `202` 和实际待确认调用。未启用模型为 `503 AI_DISABLED`。 |
| `GET /_aw/invocations/pending` | 找回当前用户仍可确认的 HTTP 和 AI 请求，不需要对话编号，也不调用模型。支持 `limit` 和 `cursor`。 |
| `POST /_aw/invocations/:id/confirm` | 仅提交空请求，针对原用户、原租户、原动作版本和原始参数重新鉴权及执行。模型没有这个工具。 |
| `POST /_aw/invocations/:id/cancel` | 只取消未执行提议；不能回滚已办业务。返回实际状态，已取消状态对应 HTTP 409。 |
| `GET /_aw/invocations/:id` | 读自己的**命令**回执。即时查询不存日志；他人及其他租户不能读取或确认。 |

命令默认 `confirmation: 'required'`；低风险业务可给普通 API 声明 `'none'`。**AI 发起的所有命令仍必须确认。** 例如：HTTP 提交费用单并确认 → 在 AI 模式说“撤回编号 1 的费用单” → 核对 `invocation.input` → 用该调用编号确认 → `GET /expenses` 看到同笔单据变回草稿。若确认订单取消前订单已发货，最终回执是业务拒绝而非成功。

待确认时仍可在同一个 `conversationId` 下提问。普通答复为 `200 {type:'reply', text, pending?}`；`pending` 是后端当前真实提议。若明确要求改参数，助手可返回新的 `202` 提议。旧 ID 与新 ID 在同一事务里交替生效；旧 ID 确认返回 `409 cancelled`。相同参数不换 ID、不延长有效期；输入不合法不撤旧提议；不能换动作或路径绑定的业务对象。若旧提议已被别人确认，本轮返回 `409 PROPOSAL_CHANGED`，不另建一笔。聊天文本“确认”不是授权。

**对话断了怎么办？** 重新登录，以 `GET /_aw/invocations/pending?limit=20` 取回 `{items, nextCursor}`。每项包括 `id`、动作、来源 `source`、原始 `input`、创建和过期时间（毫秒）。核对参数后用 `id` 确认或取消。`nextCursor` 非空时原样传给下一页，最多每页 100 条。列表按创建时间倒序；过期、无权限、旧动作版本、已关闭 AI 暴露的 AI 提议都不显示。分页期间新提议从第一页查看。这不是管理员审计接口，也不允许模型自行确认。

## 存储、幂等与故障边界

- 使用 `node:sqlite`；模板将业务记录、模块迁移和命令回执写到 `.data/product.sqlite`（可用 `ACTION_DATA_DIR` 改目录）。`migrate(db, moduleName, sqlSteps)` 按顺序在事务内迁移，禁止悄悄修改已执行的步骤。业务函数也可以使用自己的数据库或外部 API。
- 命令可带 `Idempotency-Key`。同一用户和租户重放同一请求返回原调用；相同键改动作、版本、入口或参数会被拒绝。确认默认五分钟过期；多个请求竞争同一确认时只有一个能领取执行。对改变语义的动作递增 `version`，旧提议不能按新规则执行。
- **本地写入**：`sqliteCommand(db, {...})` 的业务 SQL 和终态回执在同一事务提交。业务拒绝会撤销本次全部 SQL 并保留拒绝原因；输出校验等程序异常同样回滚，回执为 `failed / ACTION_ROLLED_BACK`。进程若在提交前退出，原 AI 提议仍待确认（未过期时），普通直接命令可凭**同一个幂等键**重试。提交后只丢响应，重放读到原回执。模块与框架必须使用同一 `DatabaseSync` **连接实例**，即使两个连接指向同一文件也不行。
- 本地处理函数和校验必须短小、同步；不要启动后台任务、自行提交事务或从中发送邮件、扣款。事务不覆盖进程内存、文件、网络或其他连接。**外部写入**仍用 `command`：仅在确定业务被拒绝时抛 `ActionError`；不确定下游是否已执行时是 `unknown`，崩溃可能留下 `running`。框架不盲重试，以 `invocationId` 和下游对账，不提供跨系统恰好一次。
- SQLite 文件应私有；调用参数、结果、幂等键不要携带凭据。部署方负责保留期、备份和容量。
- 助手会话是单实例内存状态，重启丢对话，不丢提议或回执。`ModelProvider.decide({capabilities,tools,history,now,pending?})` 返回 `reply`（包括追问）、`call` 或 `revise`；`revise` 仅接收当前动作名与完整新参数，不能指定确认编号。内置本机 Codex 默认 `gpt-6.2-sol`，可用 `CODEX_BIN`、`CODEX_MODEL` 调整。本机 CLI 不等于离线推理，使用时必要上下文会传给模型服务。
- 模板只提供本机单用户 Bearer 认证。生产宿主应替换 `authenticate`、解析实际租户与权限，接入 TLS、限流及监控；使用 cookie 时还要接入 CSRF 防护。不要直接对公网开放模板。

## 开发与升级

`npm test` 编译包、检查完整示例类型并运行行为测试；`npm audit` 检查依赖公告。0.2 是对旧 `createActions` / 全局动作名 / HTML 工作台的破坏性替换，不提供旧执行接口绕过确认。旧示例 `.data/expenses.sqlite` 不会被打开、删除或自动导入。

**从 0.2 升到 0.3**：停旧实例，做一致性数据库备份，替换框架包并重启。首次启动只追加待确认索引；历史业务记录、幂等键和回执保留。旧 `command` 不会被静默改成事务命令，只有将纯同库动作显式改为 `sqliteCommand(db, {...})` 才获得本地原子性。若要退回 0.2，使用升级前备份；迁移器会拒绝用旧版本打开更高版本的库。

**0.4 升级说明：** 无新增数据库迁移；原有 `ai: true/false` 语义不变。输出 schema 需能表示为 JSON Schema；转换后返回值请用明确的输出 schema（例如 `.transform(...).pipe(z.int())`）。既有模型适配器仍可只返回 `reply/call`；要支持修改提议，另实现 `revise`。跨版本替换需同一批服务使用一致的动作定义。

**独立产品验收：** 源码发布目录中的 `example/meeting-rooms/` 是独立 npm 项目，依赖本地 `.tgz` 而非框架源码。进入该目录执行 `npm ci && npm test`；已登录本机 Codex 时，另可 `npm run test:ai`。角色、房间和预约规则全部属于该产品，并非框架内置功能。
